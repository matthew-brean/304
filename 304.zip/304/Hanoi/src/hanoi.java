import java.util.Scanner;
public class hanoi{
	public static void hanoiTower(int numberOfBlocks,String startTower,String midTower,String endTower){
		if(numberOfBlocks>0){
		hanoiTower(numberOfBlocks-1,startTower,endTower,midTower);
		System.out.println(startTower+"->"+endTower);
		hanoiTower(numberOfBlocks-1,midTower,startTower,endTower);}}
	public static void main(String[]args){
		Scanner SCAN=new Scanner(System.in);System.out.println("***TOWER OF HANOI***");
		for(;;){
		System.out.println("# of blocks:");
		hanoiTower(SCAN.nextInt(),"A","B","C");}}}